public interface IProblem {

  double fitness(Individual individuo);

}
